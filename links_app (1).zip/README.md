# Links App - Децентрализованное приложение для хранения ссылок

**Современное веб-приложение с поддержкой упаковки в APK для Android, которое автоматически обновляет ссылки из децентрализованных источников.**

![Links App](https://img.shields.io/badge/version-1.0.0-blue) ![Platform](https://img.shields.io/badge/platform-Android-green) ![License](https://img.shields.io/badge/license-MIT-orange)

## ✨ Особенности

- 🎨 **Современный дизайн** с темной темой и градиентными акцентами
- 🔄 **Автоматическое обновление ссылок** без переделки APK
- 🌐 **Децентрализованное хранение** через GitHub, IPFS, Arweave
- 📱 **Поддержка Telegram-каналов** с прямыми ссылками
- 🔒 **Fallback система** с локальными ссылками
- 🚀 **Простое распространение** через Telegram (один APK-файл)

## 🚀 Быстрый старт

### 1. Сборка веб-приложения

```bash
cd /home/ubuntu/links_app
pnpm install
pnpm build
```

### 2. Настройка источников ссылок

Отредактируйте файл `client/src/config/sources.ts`:

```typescript
export const LINKS_SOURCES = [
  '/links.json', // Локальный fallback
  'https://raw.githubusercontent.com/YOUR_USERNAME/YOUR_REPO/main/links.json',
  // Добавьте другие источники
];
```

### 3. Создание APK

Используйте один из методов:
- **Онлайн-сервис** (WebIntoApp, AppGeyser) — самый простой способ
- **Android Studio** — для полного контроля
- **Apache Cordova** — кроссплатформенное решение

Подробные инструкции см. в файле [INSTRUCTIONS.md](./INSTRUCTIONS.md).

## 📁 Структура проекта

```
links_app/
├── client/                  # Веб-приложение
│   ├── src/
│   │   ├── pages/          # Страницы приложения
│   │   ├── components/     # React-компоненты
│   │   ├── config/         # Конфигурация источников
│   │   ├── lib/            # Утилиты
│   │   └── types/          # TypeScript типы
│   ├── public/
│   │   └── links.json      # Локальный fallback
│   └── dist/               # Собранное приложение (после build)
├── INSTRUCTIONS.md         # Подробная инструкция
└── README.md              # Этот файл
```

## 🔧 Технологии

- **Frontend:** React 19, TypeScript
- **Styling:** Tailwind CSS 4
- **UI Components:** shadcn/ui
- **Build:** Vite
- **Decentralized Storage:** GitHub Raw, IPFS, Arweave

## 📝 Формат файла links.json

```json
{
  "version": 1,
  "lastUpdated": "2025-11-11T00:00:00Z",
  "links": [
    {
      "id": "1",
      "name": "Название ссылки",
      "url": "https://example.com",
      "type": "website",
      "description": "Описание"
    },
    {
      "id": "2",
      "name": "Telegram канал",
      "url": "https://t.me/channel",
      "type": "telegram",
      "description": "Описание канала"
    }
  ]
}
```

## 🔄 Обновление ссылок

**Главное преимущество:** Обновляйте ссылки без переделки APK!

1. Отредактируйте файл `links.json` в вашем хранилище (GitHub, IPFS и т.д.)
2. Сохраните изменения
3. Пользователи автоматически получат обновления при следующем запуске

## 📱 Распространение через Telegram

1. Создайте APK-файл (см. INSTRUCTIONS.md)
2. Отправьте APK в ваш Telegram-канал
3. Пользователи скачивают и устанавливают за один клик
4. Приложение автоматически загружает актуальные ссылки

## 🛡️ Безопасность

- ✅ Все источники используют HTTPS
- ✅ Валидация JSON-данных
- ✅ Fallback на локальные ссылки
- ✅ Таймауты для предотвращения зависания
- ✅ Обработка ошибок загрузки

## 📚 Документация

- [INSTRUCTIONS.md](./INSTRUCTIONS.md) — Подробная инструкция по созданию APK и настройке
- [client/src/config/sources.ts](./client/src/config/sources.ts) — Конфигурация источников
- [client/public/links.json](./client/public/links.json) — Пример файла ссылок

## 🤝 Поддержка

Если у вас возникли вопросы или проблемы:

1. Прочитайте [INSTRUCTIONS.md](./INSTRUCTIONS.md)
2. Проверьте формат файла `links.json`
3. Убедитесь, что источники доступны

## 📄 Лицензия

MIT License - используйте свободно для любых целей.

---

**Создано с ❤️ для децентрализованного будущего**
