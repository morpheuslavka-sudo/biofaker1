export interface Link {
  id: string;
  name: string;
  url: string;
  type: 'website' | 'telegram';
  icon?: string;
  description?: string;
}

export interface LinksData {
  version: number;
  lastUpdated: string;
  links: Link[];
}
