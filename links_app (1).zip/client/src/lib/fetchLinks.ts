import { LINKS_SOURCES, FETCH_TIMEOUT } from '@/config/sources';
import type { LinksData } from '@/types/links';

/**
 * Загружает данные с таймаутом
 */
async function fetchWithTimeout(url: string, timeout: number): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeout);

  try {
    const response = await fetch(url, {
      signal: controller.signal,
      cache: 'no-cache',
      headers: {
        'Cache-Control': 'no-cache',
      },
    });
    clearTimeout(timeoutId);
    return response;
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
}

/**
 * Пытается загрузить ссылки из списка источников
 * Если первый источник недоступен, пробует следующий
 */
export async function fetchLinks(): Promise<LinksData> {
  const errors: Array<{ source: string; error: string }> = [];

  for (const source of LINKS_SOURCES) {
    try {
      console.log(`Попытка загрузки из: ${source}`);
      
      const response = await fetchWithTimeout(source, FETCH_TIMEOUT);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const data: LinksData = await response.json();
      
      // Валидация данных
      if (!data.links || !Array.isArray(data.links)) {
        throw new Error('Неверный формат данных');
      }
      
      console.log(`✓ Успешно загружено из: ${source}`);
      return data;
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Неизвестная ошибка';
      console.warn(`✗ Ошибка загрузки из ${source}:`, errorMessage);
      errors.push({ source, error: errorMessage });
    }
  }

  // Если все источники недоступны
  throw new Error(
    `Не удалось загрузить ссылки ни из одного источника.\n\n` +
    errors.map(e => `• ${e.source}: ${e.error}`).join('\n')
  );
}
