import { useEffect, useState } from 'react';
import { Loader2, RefreshCw, AlertCircle, Link as LinkIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import LinkCard from '@/components/LinkCard';
import type { LinksData } from '@/types/links';
import { fetchLinks } from '@/lib/fetchLinks';

export default function Home() {
  const [linksData, setLinksData] = useState<LinksData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadLinks = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await fetchLinks();
      setLinksData(data);
    } catch (err) {
      console.error('Error fetching links:', err);
      setError(err instanceof Error ? err.message : 'Произошла ошибка при загрузке');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLinks();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      {/* Animated background gradient */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-1/2 -right-1/2 w-full h-full bg-gradient-to-br from-primary/10 via-transparent to-transparent rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-1/2 -left-1/2 w-full h-full bg-gradient-to-tr from-primary/10 via-transparent to-transparent rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative z-10">
        {/* Header */}
        <header className="border-b border-border/50 backdrop-blur-sm bg-background/50">
          <div className="container py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-primary/50 flex items-center justify-center shadow-lg shadow-primary/20">
                  <LinkIcon className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
                    Links App
                  </h1>
                  <p className="text-sm text-muted-foreground">
                    Ваши ссылки всегда под рукой
                  </p>
                </div>
              </div>
              
              <Button
                onClick={loadLinks}
                disabled={loading}
                variant="outline"
                size="sm"
                className="gap-2"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                Обновить
              </Button>
            </div>
          </div>
        </header>

        {/* Main content */}
        <main className="container py-8">
          {loading && !linksData && (
            <div className="flex flex-col items-center justify-center py-20">
              <Loader2 className="w-12 h-12 text-primary animate-spin mb-4" />
              <p className="text-muted-foreground">Загрузка ссылок...</p>
            </div>
          )}

          {error && (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mb-4">
                <AlertCircle className="w-8 h-8 text-destructive" />
              </div>
              <h2 className="text-xl font-semibold text-foreground mb-2">
                Ошибка загрузки
              </h2>
              <p className="text-muted-foreground mb-6 text-center max-w-md">
                {error}
              </p>
              <Button onClick={loadLinks} className="gap-2">
                <RefreshCw className="w-4 h-4" />
                Попробовать снова
              </Button>
            </div>
          )}

          {linksData && !loading && (
            <div className="space-y-6">
              {/* Info banner */}
              <div className="bg-card/30 backdrop-blur-sm border border-border/50 rounded-xl p-6">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <LinkIcon className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h2 className="text-lg font-semibold text-foreground mb-1">
                      Доступные ссылки
                    </h2>
                    <p className="text-sm text-muted-foreground">
                      Всего ссылок: <span className="font-semibold text-foreground">{linksData.links.length}</span>
                      {' · '}
                      Обновлено: <span className="font-semibold text-foreground">
                        {new Date(linksData.lastUpdated).toLocaleDateString('ru-RU')}
                      </span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Links grid */}
              <div className="grid gap-4 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-2">
                {linksData.links.map((link) => (
                  <LinkCard key={link.id} link={link} />
                ))}
              </div>
            </div>
          )}
        </main>

        {/* Footer */}
        <footer className="border-t border-border/50 backdrop-blur-sm bg-background/50 mt-20">
          <div className="container py-6">
            <p className="text-center text-sm text-muted-foreground">
              Приложение автоматически обновляет ссылки при каждом запуске
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}
