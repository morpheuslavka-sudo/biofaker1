/**
 * Конфигурация источников для загрузки ссылок
 * 
 * Приложение будет пытаться загрузить ссылки из каждого источника по порядку.
 * Если первый источник недоступен, оно автоматически попробует следующий.
 * 
 * ДЕЦЕНТРАЛИЗОВАННЫЕ ВАРИАНТЫ:
 * 
 * 1. GitHub Raw (рекомендуется для начала):
 *    - Создайте публичный репозиторий на GitHub
 *    - Загрузите туда файл links.json
 *    - Используйте URL: https://raw.githubusercontent.com/USERNAME/REPO/main/links.json
 * 
 * 2. IPFS через публичный Gateway:
 *    - Загрузите links.json в IPFS (через https://ipfs.io или Pinata)
 *    - Получите CID (например: QmXxx...)
 *    - Используйте IPNS для постоянного адреса или обновляйте CID в коде
 *    - URL: https://dweb.link/ipfs/QmXxx... или https://ipfs.io/ipfs/QmXxx...
 * 
 * 3. Arweave (постоянное хранение):
 *    - Загрузите файл на Arweave
 *    - URL: https://arweave.net/TRANSACTION_ID
 * 
 * 4. Собственный сервер (менее децентрализованно):
 *    - Разместите links.json на своем сервере
 *    - URL: https://yourdomain.com/links.json
 */

export const LINKS_SOURCES = [
  // Локальный файл (fallback, всегда доступен)
  '/links.json',
  
  // Добавьте сюда свои децентрализованные источники:
  // 'https://raw.githubusercontent.com/YOUR_USERNAME/YOUR_REPO/main/links.json',
  // 'https://dweb.link/ipfs/YOUR_CID',
  // 'https://arweave.net/YOUR_TX_ID',
];

/**
 * Время ожидания для каждого источника (в миллисекундах)
 */
export const FETCH_TIMEOUT = 10000; // 10 секунд
